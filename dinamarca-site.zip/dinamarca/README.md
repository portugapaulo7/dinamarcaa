# DINAMARCA — Painel da Família

Demonstração funcional responsiva para gerenciamento da família no FiveM RP.

## Executar
Abra `index.html` no navegador. Para recursos PWA, use uma hospedagem HTTPS ou um servidor local (por exemplo, a extensão Live Server no VS Code).

## Funcionalidades
- Dashboard com totais calculados automaticamente.
- Pedidos para entrega e pedidos feitos, separados.
- Financeiro fictício com entradas, saídas e saldo calculado.
- Ações com vitórias, derrotas e taxa de vitória.
- Criar, editar, excluir (com confirmação), pesquisar e filtrar registros.
- Persistência local no navegador via `localStorage`.
- Layout responsivo e manifesto PWA.

## Limitações importantes
Esta versão é uma demonstração local. Os dados ficam somente no navegador e não sincronizam entre dispositivos. Não há autenticação, usuários, permissões reais ou conexão com Supabase/GitHub. Não insira dados secretos. O manifesto está preparado, mas o funcionamento offline completo exigiria um service worker; a instalação depende de hospedagem HTTPS e suporte do navegador.

## Próximas etapas para a versão online
1. Inspecionar o projeto Supabase existente antes de criar ou alterar tabelas.
2. Implementar autenticação Supabase Auth.
3. Criar tabelas e políticas RLS para membros, entregas, pedidos, movimentações e ações.
4. Definir permissões por cargo no banco, nunca apenas na interface.
5. Migrar persistência de `localStorage` para consultas ao Supabase e testar sincronização.
6. Criar service worker e ícones PWA finais.
7. Publicar no repositório `dinamarca` e configurar a hospedagem HTTPS.

Nunca coloque `service_role` ou outras chaves secretas no JavaScript público. Para o cliente, use apenas a chave publicável/anon com RLS corretamente configurado.
